<?php

$rand = rand(0,9);
switch ($rand) {
  case 0:
    echo '<span style="font-size:25px; color:white;">' . "<center>You will eat an OK meal today...";
    break;
  case 1:
    echo '<span style="font-size:25px; color:white;">' . "<center>There will be traffic on the way to work within the next month...";
    break;
  case 2:
    echo '<span style="font-size:25px; color:white;">' . "<center>Somebody close to you will say \"Hello\" to you in the near future...";
    break;
  case 3:
    echo '<span style="font-size:25px; color:white;">' . "<center>A sneeze is upon your future...";
    break;
  case 4:
    echo '<span style="font-size:25px; color:white;">' . "<center>The most mundane of days looms ahead...";
    break;
  case 5:
    echo '<span style="font-size:25px; color:white;">' . "<center>You are destined to find happiness...<br><br><br>Maybe...";
    break;
  case 6:
    echo '<span style="font-size:25px; color:white;">' . "<center>Exciting news is not on its way...";
    break;
  case 7:
    echo '<span style="font-size:25px; color:white;">' . "<center>Fate has many things in store for you...";
    break;
  case 8:
    echo '<span style="font-size:25px; color:white;">' . "<center>Buy our merch at phpfortunes.merchandise.ru.ch/cool-t-shirts-and-other-things";
    break;
  case 9:
    echo '<span style="font-size:25px; color:white;">' . "<center>They're in your skin...";
    break;
}

?>